package com.yuven.eq

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.media.audiofx.AudioEffect
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.ScrollView
import android.widget.Space
import android.widget.Switch
import android.widget.TextView
import com.yuven.eq.audio.YuvenAudioEngine
import com.yuven.eq.state.YuvenState

class MainActivity : Activity() {
    private lateinit var statusText: TextView
    private lateinit var playerText: TextView
    private lateinit var trackText: TextView
    private lateinit var profileText: TextView
    private lateinit var audioEngine: YuvenAudioEngine

    private val stateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) = refresh()
    }

    // Safe sideload test: listen only for Android's official audio-effect session broadcasts.
    // This avoids Notification Listener access, which Play Protect blocks for browser-sideloaded APKs.
    private val audioSessionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val session = intent.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, -1)
            val pkg = intent.getStringExtra(AudioEffect.EXTRA_PACKAGE_NAME) ?: "Music app"
            when (intent.action) {
                AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION -> {
                    if (session > 0) audioEngine.attach(session, pkg)
                }
                AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION -> {
                    audioEngine.release()
                    YuvenState.publish(this@MainActivity, "Playback stopped", pkg)
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        audioEngine = YuvenAudioEngine(this)
        registerAudioSessionReceiver()
        setContentView(buildUi())
        requestAudioPermissionIfNeeded()
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(YuvenState.ACTION_STATE_CHANGED)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(stateReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(stateReceiver, filter)
        }
        refresh()
    }

    override fun onStop() {
        try { unregisterReceiver(stateReceiver) } catch (_: Throwable) { }
        super.onStop()
    }

    override fun onDestroy() {
        try { unregisterReceiver(audioSessionReceiver) } catch (_: Throwable) { }
        audioEngine.release()
        super.onDestroy()
    }

    private fun registerAudioSessionReceiver() {
        val filter = IntentFilter().apply {
            addAction(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION)
            addAction(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(audioSessionReceiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(audioSessionReceiver, filter)
        }
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(26), dp(20), dp(24))
            setBackgroundColor(Color.BLACK)
        }

        root.addView(text("YUVEN EQ", 30f, true, Color.WHITE))
        root.addView(text("AUTO AI SOUND ENGINE • SAFE TEST V1.1", 12f, true, Color.rgb(99, 230, 190)))
        root.addView(space(20))

        val auto = Switch(this).apply {
            text = "Auto AI Enhance"
            textSize = 18f
            setTextColor(Color.WHITE)
            isChecked = true
            isEnabled = false
        }
        root.addView(auto)
        root.addView(space(16))

        statusText = text("Open Yuven EQ once, then start music", 18f, true, Color.WHITE)
        playerText = text("Player: —", 14f, false, Color.LTGRAY)
        trackText = text("Track metadata: unavailable in safe sideload mode", 14f, false, Color.LTGRAY)
        profileText = text("AI Profile: Adaptive", 14f, true, Color.rgb(99, 230, 190))
        root.addView(statusText)
        root.addView(space(6))
        root.addView(playerText)
        root.addView(trackText)
        root.addView(profileText)
        root.addView(space(18))

        root.addView(text("SAFE TEST MODE", 13f, true, Color.WHITE))
        root.addView(text("Notification access is removed from this APK so Play Protect can allow browser/file-manager installation. Keep Yuven EQ running in the background, then start YouTube Music. If the player exposes an audio-effect session, Yuven EQ will connect automatically.", 12f, false, Color.GRAY))
        root.addView(space(20))

        root.addView(text("10-BAND LOGICAL EQ", 14f, true, Color.WHITE))
        root.addView(text("V1 maps these controls to the EQ bands supported by your phone.", 12f, false, Color.GRAY))
        root.addView(space(8))

        val freqs = listOf("31", "62", "125", "250", "500", "1K", "2K", "4K", "8K", "16K")
        freqs.forEach { f ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            row.addView(text(f, 12f, false, Color.LTGRAY), LinearLayout.LayoutParams(dp(42), dp(36)))
            val seek = SeekBar(this).apply {
                max = 24
                progress = 12
                isEnabled = false
            }
            row.addView(seek, LinearLayout.LayoutParams(0, dp(36), 1f))
            root.addView(row)
        }

        root.addView(space(12))
        root.addView(text("V1 SAFETY", 13f, true, Color.WHITE))
        root.addView(text("Boost is deliberately capped while we validate clipping, device compatibility and headphone behavior.", 12f, false, Color.GRAY))

        return ScrollView(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(root)
        }
    }

    private fun refresh() {
        val s = YuvenState.read(this)
        statusText.text = s.status
        playerText.text = "Player: ${friendlyPlayer(s.player)}"
        profileText.text = "AI Profile: ${s.profile}"
    }

    private fun friendlyPlayer(pkg: String): String = when (pkg) {
        "com.google.android.apps.youtube.music" -> "YouTube Music"
        "com.spotify.music" -> "Spotify"
        "" -> "—"
        else -> pkg
    }

    private fun requestAudioPermissionIfNeeded() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1001)
        }
    }

    private fun text(value: String, sp: Float, bold: Boolean, color: Int): TextView =
        TextView(this).apply {
            text = value
            textSize = sp
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun space(heightDp: Int): Space = Space(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(heightDp))
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
