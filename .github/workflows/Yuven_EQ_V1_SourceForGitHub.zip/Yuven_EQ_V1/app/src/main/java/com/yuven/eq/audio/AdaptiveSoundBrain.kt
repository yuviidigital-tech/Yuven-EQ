package com.yuven.eq.audio

import kotlin.math.hypot

/**
 * Lightweight V1 adaptive DSP brain.
 * This is deliberately explainable heuristic DSP, not a trained ML model yet.
 * It analyzes FFT energy and produces slowly changing targets so the sound
 * does not jump on every beat.
 */
class AdaptiveSoundBrain {
    data class Decision(
        val bassStrength: Short,
        val loudnessMb: Int,
        val lowDb: Float,
        val midDb: Float,
        val highDb: Float,
        val profile: String
    )

    private var low = 0.33
    private var mid = 0.34
    private var high = 0.33

    fun analyze(fft: ByteArray, samplingRateMilliHz: Int): Decision? {
        if (fft.size < 8 || samplingRateMilliHz <= 0) return null

        val sampleRateHz = samplingRateMilliHz / 1000.0
        val bins = fft.size / 2
        if (bins < 3) return null
        val hzPerBin = (sampleRateHz / 2.0) / bins

        var lowE = 0.0
        var midE = 0.0
        var highE = 0.0

        // Android Visualizer FFT layout: real/imaginary byte pairs.
        for (i in 1 until bins) {
            val reIndex = i * 2
            val imIndex = reIndex + 1
            if (imIndex >= fft.size) break
            val re = fft[reIndex].toDouble()
            val im = fft[imIndex].toDouble()
            val mag = hypot(re, im)
            val hz = i * hzPerBin
            when {
                hz < 250.0 -> lowE += mag
                hz < 4000.0 -> midE += mag
                else -> highE += mag
            }
        }

        val total = lowE + midE + highE
        if (total <= 1.0) return null

        val instantLow = lowE / total
        val instantMid = midE / total
        val instantHigh = highE / total

        // Slow EMA: analyzes continuously but changes tonal balance smoothly.
        val a = 0.08
        low = low * (1 - a) + instantLow * a
        mid = mid * (1 - a) + instantMid * a
        high = high * (1 - a) + instantHigh * a

        val bass = (180 + ((low - 0.22) * 500).toInt()).coerceIn(120, 360).toShort()
        val loudness = (180 + ((0.36 - mid) * 300).toInt()).coerceIn(100, 350)

        val lowDb = ((0.28 - low) * 5.0).coerceIn(-1.0, 1.8).toFloat()
        val midDb = ((0.36 - mid) * 3.0).coerceIn(-0.8, 1.0).toFloat()
        val highDb = ((0.25 - high) * 4.0).coerceIn(-0.8, 1.2).toFloat()

        val profile = when {
            low > 0.42 -> "Bass control"
            mid > 0.55 -> "Vocal clarity"
            high > 0.33 -> "Smooth detail"
            else -> "Balanced adaptive"
        }

        return Decision(bass, loudness, lowDb, midDb, highDb, profile)
    }
}
