package com.yuven.eq.audio

import android.content.Context
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Visualizer
import android.os.Handler
import android.os.Looper
import com.yuven.eq.state.YuvenState
import kotlin.math.roundToInt

class YuvenAudioEngine(private val context: Context) {
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var loudness: LoudnessEnhancer? = null
    private var visualizer: Visualizer? = null
    private var sessionId: Int = -1
    private var playerPackage: String = ""
    private val brain = AdaptiveSoundBrain()
    private val main = Handler(Looper.getMainLooper())
    private var lastApplyMs = 0L

    fun attach(newSessionId: Int, packageName: String) {
        if (newSessionId <= 0) return
        if (sessionId == newSessionId && equalizer != null) return
        release()
        sessionId = newSessionId
        playerPackage = packageName

        var effectCount = 0
        try {
            equalizer = Equalizer(0, sessionId).also {
                it.enabled = true
                effectCount++
            }
        } catch (_: Throwable) { }

        try {
            bassBoost = BassBoost(0, sessionId).also {
                if (it.strengthSupported) it.setStrength(180)
                it.enabled = true
                effectCount++
            }
        } catch (_: Throwable) { }

        try {
            loudness = LoudnessEnhancer(sessionId).also {
                it.setTargetGain(150)
                it.enabled = true
                effectCount++
            }
        } catch (_: Throwable) { }

        startVisualizer()

        val status = if (effectCount > 0) {
            "Connected • Auto AI enhancing"
        } else {
            "Session detected • audio effects unavailable on this device"
        }
        YuvenState.publish(context, status, packageName, profile = "Balanced adaptive", sessionId = sessionId)
    }

    private fun startVisualizer() {
        try {
            val v = Visualizer(sessionId)
            val range = Visualizer.getCaptureSizeRange()
            v.captureSize = range[1].coerceAtMost(1024)
            v.scalingMode = Visualizer.SCALING_MODE_NORMALIZED
            val rate = (Visualizer.getMaxCaptureRate() / 2).coerceAtLeast(5000)
            v.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(
                    visualizer: Visualizer?, waveform: ByteArray?, samplingRate: Int
                ) = Unit

                override fun onFftDataCapture(
                    visualizer: Visualizer?, fft: ByteArray?, samplingRate: Int
                ) {
                    if (fft == null) return
                    val decision = brain.analyze(fft, samplingRate) ?: return
                    val now = android.os.SystemClock.elapsedRealtime()
                    if (now - lastApplyMs < 700) return
                    lastApplyMs = now
                    main.post { applyDecision(decision) }
                }
            }, rate, false, true)
            v.enabled = true
            visualizer = v
        } catch (_: SecurityException) {
            // RECORD_AUDIO not granted yet; EQ still works if the session is available.
        } catch (_: Throwable) { }
    }

    private fun applyDecision(d: AdaptiveSoundBrain.Decision) {
        try {
            bassBoost?.let { if (it.strengthSupported) it.setStrength(d.bassStrength) }
        } catch (_: Throwable) { }

        try {
            // Conservative boost cap reduces clipping risk in this early prototype.
            loudness?.setTargetGain(d.loudnessMb.coerceAtMost(350))
        } catch (_: Throwable) { }

        try {
            val eq = equalizer ?: return
            applyLogicalBand(eq, 90, d.lowDb)
            applyLogicalBand(eq, 1000, d.midDb)
            applyLogicalBand(eq, 8000, d.highDb)
        } catch (_: Throwable) { }

        YuvenState.publish(
            context,
            "Connected • Auto AI enhancing",
            playerPackage,
            profile = d.profile,
            sessionId = sessionId
        )
    }

    private fun applyLogicalBand(eq: Equalizer, frequencyHz: Int, gainDb: Float) {
        val band = eq.getBand(frequencyHz * 1000)
        val range = eq.bandLevelRange
        val targetMb = (gainDb * 100f).roundToInt().coerceIn(range[0].toInt(), range[1].toInt())
        eq.setBandLevel(band, targetMb.toShort())
    }

    fun release() {
        try { visualizer?.enabled = false } catch (_: Throwable) { }
        try { visualizer?.release() } catch (_: Throwable) { }
        try { equalizer?.release() } catch (_: Throwable) { }
        try { bassBoost?.release() } catch (_: Throwable) { }
        try { loudness?.release() } catch (_: Throwable) { }
        visualizer = null
        equalizer = null
        bassBoost = null
        loudness = null
        sessionId = -1
        playerPackage = ""
    }
}
