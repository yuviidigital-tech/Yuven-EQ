package com.yuven.eq.state

import android.content.Context
import android.content.Intent

object YuvenState {
    const val ACTION_STATE_CHANGED = "com.yuven.eq.STATE_CHANGED"
    const val EXTRA_STATUS = "status"
    const val EXTRA_PLAYER = "player"
    const val EXTRA_TRACK = "track"
    const val EXTRA_PROFILE = "profile"
    const val EXTRA_SESSION_ID = "session_id"

    fun publish(
        context: Context,
        status: String,
        player: String? = null,
        track: String? = null,
        profile: String? = null,
        sessionId: Int = -1
    ) {
        val prefs = context.getSharedPreferences("yuven_eq_state", Context.MODE_PRIVATE)
        prefs.edit()
            .putString(EXTRA_STATUS, status)
            .putString(EXTRA_PLAYER, player ?: "")
            .putString(EXTRA_TRACK, track ?: "")
            .putString(EXTRA_PROFILE, profile ?: "Adaptive")
            .putInt(EXTRA_SESSION_ID, sessionId)
            .apply()

        context.sendBroadcast(
            Intent(ACTION_STATE_CHANGED)
                .setPackage(context.packageName)
                .putExtra(EXTRA_STATUS, status)
                .putExtra(EXTRA_PLAYER, player ?: "")
                .putExtra(EXTRA_TRACK, track ?: "")
                .putExtra(EXTRA_PROFILE, profile ?: "Adaptive")
                .putExtra(EXTRA_SESSION_ID, sessionId)
        )
    }

    fun read(context: Context): Snapshot {
        val p = context.getSharedPreferences("yuven_eq_state", Context.MODE_PRIVATE)
        return Snapshot(
            p.getString(EXTRA_STATUS, "Waiting for music") ?: "Waiting for music",
            p.getString(EXTRA_PLAYER, "") ?: "",
            p.getString(EXTRA_TRACK, "") ?: "",
            p.getString(EXTRA_PROFILE, "Adaptive") ?: "Adaptive",
            p.getInt(EXTRA_SESSION_ID, -1)
        )
    }

    data class Snapshot(
        val status: String,
        val player: String,
        val track: String,
        val profile: String,
        val sessionId: Int
    )
}
