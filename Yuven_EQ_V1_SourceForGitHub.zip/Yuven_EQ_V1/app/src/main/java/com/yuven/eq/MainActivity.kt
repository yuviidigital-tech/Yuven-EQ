package com.yuven.eq

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.ScrollView
import android.widget.Space
import android.widget.Switch
import android.widget.TextView
import com.yuven.eq.state.YuvenState

class MainActivity : Activity() {
    private lateinit var statusText: TextView
    private lateinit var playerText: TextView
    private lateinit var trackText: TextView
    private lateinit var profileText: TextView

    private val stateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) = refresh()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        setContentView(buildUi())
        requestAudioPermissionIfNeeded()
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(YuvenState.ACTION_STATE_CHANGED)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(stateReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(stateReceiver, filter)
        }
        refresh()
    }

    override fun onStop() {
        try { unregisterReceiver(stateReceiver) } catch (_: Throwable) { }
        super.onStop()
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(26), dp(20), dp(24))
            setBackgroundColor(Color.BLACK)
        }

        root.addView(text("YUVEN EQ", 30f, true, Color.WHITE))
        root.addView(text("AUTO AI SOUND ENGINE • V1", 12f, true, Color.rgb(99, 230, 190)))
        root.addView(space(20))

        val auto = Switch(this).apply {
            text = "Auto AI Enhance"
            textSize = 18f
            setTextColor(Color.WHITE)
            isChecked = true
            isEnabled = false // V1 keeps AI mode on while a compatible session is active.
        }
        root.addView(auto)
        root.addView(space(16))

        statusText = text("Waiting for music", 18f, true, Color.WHITE)
        playerText = text("Player: —", 14f, false, Color.LTGRAY)
        trackText = text("Track: —", 14f, false, Color.LTGRAY)
        profileText = text("AI Profile: Adaptive", 14f, true, Color.rgb(99, 230, 190))
        root.addView(statusText)
        root.addView(space(6))
        root.addView(playerText)
        root.addView(trackText)
        root.addView(profileText)
        root.addView(space(22))

        val access = Button(this).apply {
            text = "ENABLE AUTOMATIC MUSIC DETECTION"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        }
        root.addView(access)
        root.addView(space(18))

        root.addView(text("10-BAND LOGICAL EQ", 14f, true, Color.WHITE))
        root.addView(text("V1 maps these controls to the EQ bands supported by your phone.", 12f, false, Color.GRAY))
        root.addView(space(8))

        val freqs = listOf("31", "62", "125", "250", "500", "1K", "2K", "4K", "8K", "16K")
        freqs.forEach { f ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            row.addView(text(f, 12f, false, Color.LTGRAY), LinearLayout.LayoutParams(dp(42), dp(36)))
            val seek = SeekBar(this).apply {
                max = 24
                progress = 12
                isEnabled = false // Manual EQ wiring is the next milestone.
            }
            row.addView(seek, LinearLayout.LayoutParams(0, dp(36), 1f))
            root.addView(row)
        }

        root.addView(space(12))
        root.addView(text("V1 SAFETY", 13f, true, Color.WHITE))
        root.addView(text("Boost is deliberately capped while we validate clipping, device compatibility and headphone behavior.", 12f, false, Color.GRAY))

        return ScrollView(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(root)
        }
    }

    private fun refresh() {
        val s = YuvenState.read(this)
        statusText.text = s.status
        playerText.text = "Player: ${friendlyPlayer(s.player)}"
        trackText.text = if (s.track.isBlank()) "Track: —" else "Track: ${s.track}"
        profileText.text = "AI Profile: ${s.profile}"
    }

    private fun friendlyPlayer(pkg: String): String = when (pkg) {
        "com.google.android.apps.youtube.music" -> "YouTube Music"
        "com.spotify.music" -> "Spotify"
        "" -> "—"
        else -> pkg
    }

    private fun requestAudioPermissionIfNeeded() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1001)
        }
    }

    private fun text(value: String, sp: Float, bold: Boolean, color: Int): TextView =
        TextView(this).apply {
            text = value
            textSize = sp
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun space(heightDp: Int): Space = Space(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(heightDp))
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
