package com.yuven.eq.service

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.audiofx.AudioEffect
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.os.Build
import android.service.notification.NotificationListenerService
import com.yuven.eq.audio.YuvenAudioEngine
import com.yuven.eq.state.YuvenState

class MusicMonitorService : NotificationListenerService() {
    private lateinit var audioEngine: YuvenAudioEngine
    private lateinit var mediaSessionManager: MediaSessionManager
    private var controllerCallbacks = mutableMapOf<MediaController, MediaController.Callback>()

    private val audioSessionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val session = intent.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, -1)
            val pkg = intent.getStringExtra(AudioEffect.EXTRA_PACKAGE_NAME) ?: "Music app"
            when (intent.action) {
                AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION -> {
                    if (session > 0) audioEngine.attach(session, pkg)
                }
                AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION -> {
                    audioEngine.release()
                    YuvenState.publish(this@MusicMonitorService, "Playback stopped", pkg)
                }
            }
        }
    }

    private val sessionsChanged = MediaSessionManager.OnActiveSessionsChangedListener { controllers ->
        watchControllers(controllers.orEmpty())
    }

    override fun onCreate() {
        super.onCreate()
        audioEngine = YuvenAudioEngine(this)
        mediaSessionManager = getSystemService(MediaSessionManager::class.java)
        registerAudioSessionReceiver()
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        val me = ComponentName(this, MusicMonitorService::class.java)
        try {
            mediaSessionManager.addOnActiveSessionsChangedListener(sessionsChanged, me)
            watchControllers(mediaSessionManager.getActiveSessions(me))
        } catch (_: SecurityException) {
            YuvenState.publish(this, "Grant notification access to detect music automatically")
        }
    }

    private fun registerAudioSessionReceiver() {
        val filter = IntentFilter().apply {
            addAction(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION)
            addAction(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(audioSessionReceiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(audioSessionReceiver, filter)
        }
    }

    private fun watchControllers(controllers: List<MediaController>) {
        controllerCallbacks.forEach { (controller, callback) ->
            try { controller.unregisterCallback(callback) } catch (_: Throwable) { }
        }
        controllerCallbacks.clear()

        if (controllers.isEmpty()) {
            YuvenState.publish(this, "Waiting for music")
            return
        }

        controllers.forEach { controller ->
            val callback = object : MediaController.Callback() {
                override fun onPlaybackStateChanged(state: android.media.session.PlaybackState?) {
                    publishControllerState(controller)
                }

                override fun onMetadataChanged(metadata: android.media.MediaMetadata?) {
                    publishControllerState(controller)
                }
            }
            controller.registerCallback(callback)
            controllerCallbacks[controller] = callback
        }

        val playing = controllers.firstOrNull {
            it.playbackState?.state == android.media.session.PlaybackState.STATE_PLAYING
        } ?: controllers.first()
        publishControllerState(playing)
    }

    private fun publishControllerState(controller: MediaController) {
        val playing = controller.playbackState?.state == android.media.session.PlaybackState.STATE_PLAYING
        val title = controller.metadata?.getString(android.media.MediaMetadata.METADATA_KEY_TITLE).orEmpty()
        val artist = controller.metadata?.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST).orEmpty()
        val track = listOf(title, artist).filter { it.isNotBlank() }.joinToString(" • ")
        val existing = YuvenState.read(this)

        val status = when {
            existing.sessionId > 0 && playing -> "Connected • Auto AI enhancing"
            playing -> "Music detected • waiting for compatible audio-effect session"
            else -> "Music app detected • paused"
        }

        YuvenState.publish(
            this,
            status,
            controller.packageName,
            track,
            existing.profile,
            existing.sessionId
        )
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        try { mediaSessionManager.removeOnActiveSessionsChangedListener(sessionsChanged) } catch (_: Throwable) { }
    }

    override fun onDestroy() {
        try { unregisterReceiver(audioSessionReceiver) } catch (_: Throwable) { }
        try { mediaSessionManager.removeOnActiveSessionsChangedListener(sessionsChanged) } catch (_: Throwable) { }
        controllerCallbacks.forEach { (controller, callback) ->
            try { controller.unregisterCallback(callback) } catch (_: Throwable) { }
        }
        controllerCallbacks.clear()
        audioEngine.release()
        super.onDestroy()
    }
}
